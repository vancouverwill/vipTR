<?php
/**
 * The base configurations of the WordPress.
 *
 * This file has the following configurations: MySQL settings, Table Prefix,
 * Secret Keys, WordPress Language, and ABSPATH. You can find more information
 * by visiting {@link http://codex.wordpress.org/Editing_wp-config.php Editing
 * wp-config.php} Codex page. You can get the MySQL settings from your web host.
 *
 * This file is used by the wp-config.php creation script during the
 * installation. You don't have to use the web site, you can just copy this file
 * to "wp-config.php" and fill in the values.
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define('DB_NAME', 'vipelectrical');

/** MySQL database username */
define('DB_USER', 'root');

/** MySQL database password */
define('DB_PASSWORD', 'skate8642');

/** MySQL hostname */
define('DB_HOST', 'localhost');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         'BF^_>n?A`0IsSG4--!5zGhiSy8AV,3-l[w6/{j@D~HhS_D;HXQ.*3+<)-<dEw5 c');
define('SECURE_AUTH_KEY',  '&oZdcw7>gLj~GmiL4p#E,r#8Di %!7s9>Oor]TOrI!<)ZG<t$~e%>~aXM*5:d-kA');
define('LOGGED_IN_KEY',    '<)} -V3SNj R4+Ig9WBv!XyPk1I|hv?]bWtFZ*[-4W+,h6D[9hHR{k>{(Wds[CpC');
define('NONCE_KEY',        'h1z%<?0]r>u6DaK5iWmEf)BK%e)3_VTZ~sd/W5MpzxphKU](.-I:/^O[7>^HY{cR');
define('AUTH_SALT',        'Z;M/zEps8m{jEr}ERCz&6T.m>PIq-4t< ==ALaCZpmOWy)Y:7qFl=(B|&,p BW%=');
define('SECURE_AUTH_SALT', 'Y_e7M$jxF6sqSZ&^rQlC, H>)r }6LME[4JPOELEpczUyOr;F(LEyrZZAI`1BcBI');
define('LOGGED_IN_SALT',   '+/vxVC]xv}XY[tH0MaWDX$eBqJ/AYmGsk#3>@^]k_Kl,g{(RwaPSnKu-8fDb[]n)');
define('NONCE_SALT',       '4oUGO.$3!.`w|WH2sGRyx1<q<<JYzY%I[$0bYk5)j+bwjpY54c+=+]{N8$^xu?+g');

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each a unique
 * prefix. Only numbers, letters, and underscores please!
 */
$table_prefix  = 'wp_';

/**
 * WordPress Localized Language, defaults to English.
 *
 * Change this to localize WordPress. A corresponding MO file for the chosen
 * language must be installed to wp-content/languages. For example, install
 * de_DE.mo to wp-content/languages and set WPLANG to 'de_DE' to enable German
 * language support.
 */
define('WPLANG', '');

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 */
define('WP_DEBUG', false);

/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');

